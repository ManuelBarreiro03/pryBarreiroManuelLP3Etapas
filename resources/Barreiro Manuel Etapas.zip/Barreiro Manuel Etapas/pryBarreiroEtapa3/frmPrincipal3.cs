﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pryBarreiroEtapa3
{
    public partial class frmPrincipal3 : Form
    {
        clsVehiculos objVehiculo;
        public frmPrincipal3()
        {
            InitializeComponent();
        }
        Random rdmPosY = new Random(); 
        Random rdmPosX = new Random();
        int Ancho = 0;
        int largo = 0;
        int cod = 0;

        private void cmdCrear_Click(object sender, EventArgs e)
        {

            if (cmbTipo.Text == "Auto")
            {
                cod = 1;
                Ancho = rdmPosX.Next(0, 400);
                largo = rdmPosY.Next(0, 400);
                objVehiculo = new clsVehiculos();
                objVehiculo.CrearVehiculo(cod);
                objVehiculo.imgVehiculo.Location = new Point(Ancho, largo);
                Controls.Add(objVehiculo.imgVehiculo);
                lblNombre.Text += " " + objVehiculo.nombre;
                lblTipo.Text += " " + objVehiculo.tipo;
            }
            if (cmbTipo.Text == "Camion")
            {
                cod = 2;
                Ancho = rdmPosX.Next(0, 400);
                largo = rdmPosY.Next(0, 400);
                objVehiculo = new clsVehiculos();
                objVehiculo.CrearVehiculo(cod);
                objVehiculo.imgVehiculo.Location = new Point(Ancho, largo);
                Controls.Add(objVehiculo.imgVehiculo);
                lblNombre.Text += " " + objVehiculo.nombre;
                lblTipo.Text += " " + objVehiculo.tipo;

            }
            if (cmbTipo.Text == "Moto")
            {
                cod = 3;
                Ancho = rdmPosX.Next(0, 400);
                largo = rdmPosY.Next(0, 400);
                objVehiculo = new clsVehiculos();
                objVehiculo.CrearVehiculo(cod);
                objVehiculo.imgVehiculo.Location = new Point(Ancho, largo);
                Controls.Add(objVehiculo.imgVehiculo);
                lblNombre.Text += " " + objVehiculo.nombre;
                lblTipo.Text += " " + objVehiculo.tipo;
            }
            if (cmbTipo.Text == "")
            {
                MessageBox.Show("Nada seleccionado");
            }
        }

        private void cmdEliminar_Click(object sender, EventArgs e)
        {
            objVehiculo.imgVehiculo.Dispose();
        }
    }
}
