﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pryBarreiroEtapa6
{
    internal class clsVehiculos
    {
        string nombre;
        string tipo;
        public PictureBox imgVehiculo;
        public PictureBox imgNave;
        public PictureBox imgBala;

        public void CrearAuto()
        {
            nombre = "Corsa";
            tipo = "Auto";
            imgVehiculo = new PictureBox();
            imgVehiculo.SizeMode = PictureBoxSizeMode.StretchImage;
            string rutaConte = @"../../../" + "/Resources/" + "Corsa.jpg";
            imgVehiculo.ImageLocation = rutaConte;
        }
        public void CrearCamion()
        {
            nombre = "Scania";
            tipo = "Camion";
            imgVehiculo = new PictureBox();
            imgVehiculo.SizeMode = PictureBoxSizeMode.StretchImage;
            string rutaConte = @"../../../" + "/Resources/" + "Scania.jpg";
            imgVehiculo.ImageLocation = rutaConte;
        }
        public void CrearNave() 
        {
            nombre = "Personaje";
            tipo = "Nave";
            imgNave = new PictureBox();
            imgNave.SizeMode = PictureBoxSizeMode.StretchImage;
            imgNave.Size = new Size(50, 50);
            string rutaConte = @"../../../" + "/Resources/" + "Nave.PNG";
            imgNave.ImageLocation = rutaConte;
        }
        public void CrearMoto()
        {
            nombre = "BMW";
            tipo = "Moto";
            imgVehiculo = new PictureBox();
            imgVehiculo.SizeMode = PictureBoxSizeMode.StretchImage;
            string rutaConte = @"../../../" + "/Resources/" + "BMW.jpg";
            imgVehiculo.ImageLocation = rutaConte;
        }
        public void CrearVehiculoAleatorio()
        {
            Random rdmVehiculo = new Random();
            int Vehiculo;
            Vehiculo = rdmVehiculo.Next(1, 4);
            if (Vehiculo == 1)
            {
                CrearAuto();
            }
            if (Vehiculo == 3)
            {
                CrearCamion();
            }
            if (Vehiculo == 2)
            {
                CrearMoto();
            }
        }
        public void CrearBala()
        {
            nombre = "Bala";
            imgBala = new PictureBox();
            imgBala.SizeMode = PictureBoxSizeMode.AutoSize;
            string rutaConte = @"../../../" + "/Resources/" + "Laser.PNG";
            imgBala.ImageLocation = rutaConte;
        }
    }
}
