﻿using pryBarreiroEstapa2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pryBarreiroEtapa6
{
    public partial class frmInicio : Form
    {
        public frmInicio()
        {
            InitializeComponent();
        }

        private void cmdCrear_Click(object sender, EventArgs e)
        {
            frmPrincipal6 Principal6 = new frmPrincipal6();
            if (cmbCant.Text != "")
            {
                Principal6.cant = Convert.ToInt32(cmbCant.Text);
                this.Hide();
                Principal6.ShowDialog();
                this.Close(); 
            }
            else
            {
                MessageBox.Show("Seleccionar Cantidad");
            }
        }
    }
}
