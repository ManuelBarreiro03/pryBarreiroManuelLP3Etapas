﻿namespace pryBarreiroEtapa6
{
    partial class frmInicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmdCrear = new Button();
            lblCant = new Label();
            cmbCant = new ComboBox();
            SuspendLayout();
            // 
            // cmdCrear
            // 
            cmdCrear.Location = new Point(12, 62);
            cmdCrear.Name = "cmdCrear";
            cmdCrear.Size = new Size(155, 42);
            cmdCrear.TabIndex = 0;
            cmdCrear.Text = "Crear";
            cmdCrear.UseVisualStyleBackColor = true;
            cmdCrear.Click += cmdCrear_Click;
            // 
            // lblCant
            // 
            lblCant.AutoSize = true;
            lblCant.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblCant.Location = new Point(12, 9);
            lblCant.Name = "lblCant";
            lblCant.Size = new Size(155, 21);
            lblCant.TabIndex = 1;
            lblCant.Text = "Seleccionar Cantidad";
            // 
            // cmbCant
            // 
            cmbCant.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCant.FormattingEnabled = true;
            cmbCant.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6" });
            cmbCant.Location = new Point(12, 33);
            cmbCant.Name = "cmbCant";
            cmbCant.Size = new Size(155, 23);
            cmbCant.TabIndex = 2;
            // 
            // frmInicio
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(177, 113);
            Controls.Add(cmbCant);
            Controls.Add(lblCant);
            Controls.Add(cmdCrear);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmInicio";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Inicio";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button cmdCrear;
        private Label lblCant;
        private ComboBox cmbCant;
    }
}