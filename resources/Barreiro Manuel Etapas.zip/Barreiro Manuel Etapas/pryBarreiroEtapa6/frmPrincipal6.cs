﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Windows;
using pryBarreiroEtapa6;

namespace pryBarreiroEstapa2
{
    public partial class frmPrincipal6 : Form
    {
        clsVehiculos objVehiculo;
        clsVehiculos objNave;
        List<clsVehiculos> lstVehiculos = new List<clsVehiculos>();
        List<clsVehiculos> lstBala = new List<clsVehiculos>();
        int Ancho = 0, largo = 0,  cont = 0, lugar=20;
        public int cant;
        Random rdmPosY = new Random();
        Random rdmPosX = new Random();
        public frmPrincipal6()
        {
            InitializeComponent();
        }

        private void timerMovimiento_Tick(object sender, EventArgs e)
        {

            foreach (clsVehiculos bala in lstBala)
            {
                if (bala.imgBala.Location.Y > 0)
                {
                    bala.imgBala.Location = new Point(bala.imgBala.Location.X, bala.imgBala.Location.Y - 50);
                    foreach (Control imagen in Controls)
                    {
                        if (imagen.Tag == "Vehiculo")
                        {
                            if (bala.imgBala.Bounds.IntersectsWith(imagen.Bounds))
                            {
                                bala.imgBala.Dispose();
                                imagen.Dispose();
                            }
                        }
                    }
                }
                else
                {
                    bala.imgBala.Dispose();
                }
            }
        }

        private void frmPrincipal6_KeyDown(object sender, KeyEventArgs e)
        {
            if (objNave.imgNave.Location.Y != 0 && objNave.imgNave.Location.X != 0)
            {
                if (e.KeyCode == Keys.Right)
                {
                    objNave.imgNave.Location = new Point(objNave.imgNave.Location.X + 30, objNave.imgNave.Location.Y);
                }
                if (e.KeyCode == Keys.Left)
                {
                    objNave.imgNave.Location = new Point(objNave.imgNave.Location.X - 30, objNave.imgNave.Location.Y);
                }
                if (e.KeyCode == Keys.Up)
                {
                    objNave.imgNave.Location = new Point(objNave.imgNave.Location.X, objNave.imgNave.Location.Y - 30);
                }
                if (e.KeyCode == Keys.Down)
                {
                    objNave.imgNave.Location = new Point(objNave.imgNave.Location.X, objNave.imgNave.Location.Y + 30);
                }
            }
            if (e.KeyCode == Keys.Space)
            {
                objNave.CrearBala();
                lstBala.Add(objNave);
                objNave.imgBala.Location = new Point(objNave.imgNave.Location.X, objNave.imgNave.Location.Y);
                objNave.imgNave.BringToFront();
                Controls.Add(objNave.imgBala);
            }
        }

        private void frmPrincipal6_Load(object sender, EventArgs e)
        {
            cont = 0;
            while (cont < cant)
            {
                largo = 20;
                objVehiculo = new clsVehiculos();
                objVehiculo.CrearVehiculoAleatorio();
                lstVehiculos.Add(objVehiculo);
                objVehiculo.imgVehiculo.Tag = "Vehiculo";
                objVehiculo.imgVehiculo.Location = new Point(lugar, largo);
                Controls.Add(objVehiculo.imgVehiculo);
                cont++;
                lugar = lugar + 120;
            }
            objNave = new clsVehiculos();
            objNave.CrearNave();
            lstVehiculos.Add(objVehiculo);
            objNave.imgNave.Location = new Point(300, 380);
            Controls.Add(objNave.imgNave);
        }
    }
}
