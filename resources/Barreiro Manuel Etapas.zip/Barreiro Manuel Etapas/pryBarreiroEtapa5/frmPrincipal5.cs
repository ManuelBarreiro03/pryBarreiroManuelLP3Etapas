﻿using pryBarreiroEtapa5;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pryBarreiroEtapa5
{
    public partial class frmPrincipal5 : Form
    {
        public frmPrincipal5()
        {
            InitializeComponent();
        }

        clsVehiculos objVehiculo;
        Random rdmPosY = new Random();
        Random rdmPosX = new Random();
        int Ancho = 0;
        int largo = 0;

        private void cmdCrear_Click(object sender, EventArgs e)
        {
            Ancho = rdmPosX.Next(0, 400);
            largo = rdmPosY.Next(0, 400);
            objVehiculo = new clsVehiculos();
            objVehiculo.CrearVehiculoAleatorio();
            objVehiculo.imgVehiculo.Location = new Point(Ancho, largo);
            Controls.Add(objVehiculo.imgVehiculo);
        }
    }
}
