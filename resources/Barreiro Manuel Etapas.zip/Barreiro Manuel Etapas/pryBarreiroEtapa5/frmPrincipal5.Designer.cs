﻿namespace pryBarreiroEtapa5
{
    partial class frmPrincipal5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmdCrear = new Button();
            SuspendLayout();
            // 
            // cmdCrear
            // 
            cmdCrear.Location = new Point(667, 396);
            cmdCrear.Name = "cmdCrear";
            cmdCrear.Size = new Size(121, 42);
            cmdCrear.TabIndex = 1;
            cmdCrear.Text = "Crear aleatorio";
            cmdCrear.UseVisualStyleBackColor = true;
            cmdCrear.Click += cmdCrear_Click;
            // 
            // frmPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(cmdCrear);
            Name = "frmPrincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Principal";
            ResumeLayout(false);
        }

        #endregion

        private Button cmdCrear;
    }
}