﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pryBarreiroEstapa2
{
    internal class clsVehiculos
    {
        string nombre;
        string tipo;
        public PictureBox imgVehiculo;
        
        public void CrearVehiculo()
        {
            nombre = "Corsa";
            tipo = "Auto";
            imgVehiculo = new PictureBox();
            imgVehiculo.SizeMode = PictureBoxSizeMode.StretchImage;
            string rutaConte = @"../../../" + "/resources/" + "Corsa.jpg";
            imgVehiculo.ImageLocation = rutaConte;
        }
    }
}
