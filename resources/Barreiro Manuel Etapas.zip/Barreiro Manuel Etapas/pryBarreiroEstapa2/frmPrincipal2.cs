﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Windows;

namespace pryBarreiroEstapa2
{
    public partial class frmPrincipal2 : Form
    {
        clsVehiculos objVehiculo;
        
        public frmPrincipal2()
        {
            InitializeComponent();
        }

        private void cmdCrear_Click(object sender, EventArgs e)
        {
            objVehiculo = new clsVehiculos();
            objVehiculo.CrearVehiculo();
            objVehiculo.imgVehiculo.Location = new Point(155,155);
            Controls.Add(objVehiculo.imgVehiculo);
        }
    }
}
