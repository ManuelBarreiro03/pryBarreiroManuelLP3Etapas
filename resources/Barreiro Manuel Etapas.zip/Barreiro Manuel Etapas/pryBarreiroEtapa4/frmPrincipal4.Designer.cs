﻿namespace pryBarreiroEtapa3
{
    partial class frmPrincipal4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmdCrear = new Button();
            cmbTipo = new ComboBox();
            cmdEliminar = new Button();
            SuspendLayout();
            // 
            // cmdCrear
            // 
            cmdCrear.Location = new Point(540, 396);
            cmdCrear.Name = "cmdCrear";
            cmdCrear.Size = new Size(121, 42);
            cmdCrear.TabIndex = 0;
            cmdCrear.Text = "Crear";
            cmdCrear.UseVisualStyleBackColor = true;
            cmdCrear.Click += cmdCrear_Click;
            // 
            // cmbTipo
            // 
            cmbTipo.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbTipo.FormattingEnabled = true;
            cmbTipo.Items.AddRange(new object[] { "Auto", "Camion", "Moto" });
            cmbTipo.Location = new Point(540, 367);
            cmbTipo.Name = "cmbTipo";
            cmbTipo.Size = new Size(248, 23);
            cmbTipo.TabIndex = 1;
            // 
            // cmdEliminar
            // 
            cmdEliminar.Location = new Point(667, 396);
            cmdEliminar.Name = "cmdEliminar";
            cmdEliminar.Size = new Size(121, 42);
            cmdEliminar.TabIndex = 2;
            cmdEliminar.Text = "Eliminar";
            cmdEliminar.UseVisualStyleBackColor = true;
            cmdEliminar.Click += cmdEliminar_Click;
            // 
            // frmPrincipal4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(cmdEliminar);
            Controls.Add(cmbTipo);
            Controls.Add(cmdCrear);
            Name = "frmPrincipal4";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Principal";
            ResumeLayout(false);
        }

        #endregion

        private Button cmdCrear;
        private ComboBox cmbTipo;
        private Button cmdEliminar;
    }
}