﻿using pryBarreiroEtapa4;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pryBarreiroEtapa3
{
    public partial class frmPrincipal4 : Form
    {
        clsVehiculos objVehiculo;
        List<clsVehiculos> lstVehiculos = new List<clsVehiculos>();
        public frmPrincipal4()
        {
            InitializeComponent();
        }
        Random rdmPosY = new Random(); 
        Random rdmPosX = new Random();
        int Ancho = 0;
        int largo = 0;

        private void cmdCrear_Click(object sender, EventArgs e)
        {

            if (cmbTipo.Text == "Auto")
            {
                Ancho = rdmPosX.Next(0, 400);
                largo = rdmPosY.Next(0, 400);
                objVehiculo = new clsVehiculos();
                objVehiculo.CrearAuto();
                lstVehiculos.Add(objVehiculo);
                objVehiculo.imgVehiculo.Location = new Point(Ancho, largo);
                Controls.Add(objVehiculo.imgVehiculo);
            }
            if (cmbTipo.Text == "Camion")
            {
                Ancho = rdmPosX.Next(0, 400);
                largo = rdmPosY.Next(0, 400);
                objVehiculo = new clsVehiculos();
                objVehiculo.CrearCamion();
                lstVehiculos.Add(objVehiculo);
                objVehiculo.imgVehiculo.Location = new Point(Ancho, largo);
                Controls.Add(objVehiculo.imgVehiculo);

            }
            if (cmbTipo.Text == "Moto")
            {
                Ancho = rdmPosX.Next(0, 400);
                largo = rdmPosY.Next(0, 400);
                objVehiculo = new clsVehiculos();
                objVehiculo.CrearMoto();
                lstVehiculos.Add(objVehiculo);
                objVehiculo.imgVehiculo.Location = new Point(Ancho, largo);
                Controls.Add(objVehiculo.imgVehiculo);
            }
            if (cmbTipo.Text == "")
            {
                MessageBox.Show("Nada seleccionado");
            }
            
        }

        private void cmdEliminar_Click(object sender, EventArgs e)
        {
            foreach (var obj in lstVehiculos)
            {
                obj.imgVehiculo.Dispose();
            }
            lstVehiculos.Clear();
        }
    }
}
