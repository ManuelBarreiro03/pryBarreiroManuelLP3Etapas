﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pryBarreiroEtapa4
{
    internal class clsVehiculos
    {
        string nombre;
        string tipo;
        public PictureBox imgVehiculo;

        public void CrearAuto()
        {
            nombre = "Corsa";
            tipo = "Auto";
            imgVehiculo = new PictureBox();
            imgVehiculo.SizeMode = PictureBoxSizeMode.StretchImage;
            string rutaConte = @"../../../" + "/resources/" + "Corsa.jpg";
            imgVehiculo.ImageLocation = rutaConte;
        }
        public void CrearCamion()
        {
            nombre = "Scania";
            tipo = "Camion";
            imgVehiculo = new PictureBox();
            imgVehiculo.SizeMode = PictureBoxSizeMode.StretchImage;
            string rutaConte = @"../../../" + "/resources/" + "Scania.jpg";
            imgVehiculo.ImageLocation = rutaConte;
        }
        public void CrearMoto()
        {
            nombre = "BMW";
            tipo = "Moto";
            imgVehiculo = new PictureBox();
            imgVehiculo.SizeMode = PictureBoxSizeMode.StretchImage;
            string rutaConte = @"../../../" + "/resources/" + "BMW.jpg";
            imgVehiculo.ImageLocation = rutaConte;
        }
    }
}
